﻿namespace AreaDeUncir;

class AreaDeUnCirculo
{
    static void Main(string[] args)
    {
        Console.WriteLine("CALCULADOR DE AREA DE UN CIRCULO");
        Console.WriteLine("Escriba el radio del circulo: ");
        double rad = Convert.ToDouble(Console.ReadLine());
        double area = 3.1416 * (rad * rad);

        Console.WriteLine($"El area de su circulo de radio {rad} es de: {area}cm2");
        
    }
}
