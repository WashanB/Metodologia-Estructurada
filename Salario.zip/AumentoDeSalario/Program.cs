﻿using System;
using System.Security;

namespace AumentoDeSalario;

class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Escriba su nombre: ");
        string name = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Cual es su caargo en la empresa?:");
        string cargo = Convert.ToString(Console.ReadLine());
        Console.WriteLine("Cual es su salario mensual");
        double salario = Convert.ToDouble(Console.ReadLine());
        double nuevoSAL = (salario * 0.10) + salario;
        Console.WriteLine($"Nombre: {name.ToUpper()}");
        Console.WriteLine($"Cargo: {cargo.ToUpper()}");
        Console.WriteLine($"Antiguo salario: {salario} ");
        Console.WriteLine($"El nuevo salario es: {nuevoSAL}");



    }




}

