﻿using System;

namespace ParOimPar
{
    class Program
    {
        static void Main(string[] args) {

            //Programa hecho sin condicionales
            Console.WriteLine("Escriba un numero para saber si es impar o par:");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Si dice TRUE es Par \nSi dice FALSE es impar");
            bool Par = number % 2 == 0;
            Console.WriteLine(Par);
        
        
        
        
        }
        
        
        
        
    }
}

